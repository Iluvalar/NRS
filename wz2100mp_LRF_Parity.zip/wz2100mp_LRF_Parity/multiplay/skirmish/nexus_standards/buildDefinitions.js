
const BASE_STRUCTURES = {
	factories: [ "A0LightFactory", ],
	templateFactories: [ "A0CyborgFactory", ],
	vtolFactories: [ "A0VTolFactory1", ],
	labs: [ "A0ResearchFacility", ],
	gens: [ "A0PowerGenerator", ],
	hqs: [ "A0CommandCentre", ],
	vtolPads: [ "A0VtolPad", ],
	derricks: [ "A0ResourceExtractor", ],
	uplinks: [ "A0Sat-linkCentre", ],
	repairBays: [ "A0RepairCentre3", ],
	lassats: [ "A0LasSatCommand", ],
	sensors: [ "Sys-SensoTower02", ],
};

const FEATURE_STATS = {
	oils: [ "OilResource", ],
};

const STANDARD_TARGET_WEIGHTS = [
	{stat: FACTORY, value: 10,},
	{stat: CYBORG_FACTORY, value: 10,},
	{stat: VTOL_FACTORY, value: 10,},
	{stat: RESOURCE_EXTRACTOR, value: 9,},
	{stat: HQ, value: 8,},
	{stat: RESEARCH_LAB, value: 7,},
	{stat: POWER_GEN, value: 7,},
	{stat: LASSAT, value: 6,},
	{stat: SAT_UPLINK, value: 6,},
	{stat: REARM_PAD, value: 5,},
	{stat: REPAIR_FACILITY, value: 5,},
];

const STANDARD_MORTAR_DEFENSES = [
	"Emplacement-MortarPit01",
	"Emplacement-MortarPit02",
	"Emplacement-RotMor",
];

const STANDARD_HOWITZER_DEFENSES = [
	"Emplacement-Howitzer105",
	"Emplacement-Howitzer150",
	"Emplacement-RotHow",
];

const STANDARD_INCENDIARIES = [
	"Emplacement-MortarPit-Incendiary",
	"Emplacement-Howitzer-Incendiary",
	"Emplacement-HeavyPlasmaLauncher",
];

const STANDARD_ANTI_AIR_DEFENSES = [
	"AASite-QuadMg1",
	"GuardTower-AA-QuadMg1",
	"WallTower-QuadMg1",
	"P0-AASite-Sunburst",
	"GuardTower-AA-Sunburst",
	"WallTower-Sunburst",
	"AASite-QuadBof",
	"GuardTower-AA-DoubleAAGun",
	"WallTower-DoubleAAGun",
	"AASite-QuadBof02",
	"WallTower-DoubleAAGun02",
	"GuardTower-AA-DoubleAAGun02",
	"AASite-QuadRotMg",
	"GuardTower-AA-QuadRotAAGun1",
	"WallTower-QuadRotAAGun",
	"P0-AASite-SAM1",
	"GuardTower-AA-SamSite",
	"WallTower-SamSite",
	"P0-AASite-Laser",
	"GuardTower-AA-Laser",
	"WallTower-AALaser",
	"P0-AASite-SAM2",
	"GuardTower-AA-SamHvy",
	"WallTower-SamHvy",
];

//Always builds one of these structures in base.
const STANDARD_BUILD_FUNDAMENTALS = [
	"A0LightFactory",
	"A0ResearchFacility",
	"A0PowerGenerator",
	"A0CommandCentre",
	"A0CyborgFactory",
	"A0RepairCentre3",
	"Sys-CB-Tower01",
	"A0LasSatCommand",
	"A0Sat-linkCentre",
	"X-Super-Rocket",
	"X-Super-Cannon",
	"X-Super-MassDriver",
	"X-Super-Missile",
];

//NOTE: Nexus estimates the "bounds" of an ally base by enumerating all of these. Kind of like "territory".
const STANDARD_BASE_STRUCTURES = [
	"A0PowerGenerator",
	"A0LightFactory",
	"A0CommandCentre",
	"A0ResearchFacility",
	"A0CyborgFactory",
	"A0LasSatCommand",
	"A0Sat-linkCentre",
	"A0VTolFactory1",
];

// NOTE: Apparently, these are randomly selected to an extend.
const STANDARD_BASIC_DEFENSES = [
	"PillBox1",
	"PillBox2",
	"PillBox3",
	"WallTower01",
	"GuardTower6",
	"PillBox-Rocket-Pod",
	"Pillbox-RotMG",
	"Wall-RotMg",
	"PillBox4",
	"PillBox6",
	"WallTower06",
	"WallTower03",
	"WallTower04",
	"PillBox-Cannon4",
	"WallTower-HPVcannon",
	"WallTower-HPVcannonHvy",
	"PillBox-HvATrocket",
	"WallTower-HvATrocket",
	"PillBox-LaserPulse",
	"WallTower-Rail1",
	"PillBox-Rail1",
	"PillBox-Rail2",
	"WallTower-PulseFlashlight",
	"WallTower-PulseLas",
	"WallTower-Rail2",
	"WallTower-Atmiss",
	"WallTower-PulseLasHeavy",
	"WallTower-Rail3",
	"Sys-SpyTower"
];

// NOTE: build on the ourskirt of the base "territory"
const STANDARD_FORTIFY_DEFENSES = [
	"WallTower01",
	"WallTower02",
	"WallTower03",
	"WallTower06",
	"WallTower-HPVcannon",
	"Wall-VulcanCan",
	"WallTower-HPVcannonHvy",
	"WallTower-TwinAssaultCannon",
	"Wall-VulcanCanHvy",
	"WallTower04",
	"WallTower-HvATrocket",
	"WallTower-Rail1",
	"WallTower-Rail2",
	"WallTower-PulseLas",
	"WallTower-PulseLasHeavy",
	"WallTower-Atmiss",
	"WallTower-Rail3",
	"Sys-SpyTower",
];

//NOTE: if any of these are destroyed, requeue them for a rebuilt at that spot.
const STANDARD_REBUILD_STRUCTURES = [
	{type: WALL, stat: "A0HardcreteMk1Wall", name: "Hardcrete Wall"},
	{type: WALL, stat: "A0HardcreteMk1CWall", name: "Hardcrete Corner Wall"},
];
